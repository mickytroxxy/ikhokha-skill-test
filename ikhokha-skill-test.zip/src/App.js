import Routes from './components/Routes';
import './App.css';

function App() {
  return (
    <div className="App">
      <Routes />
    </div>
  );
}

export default App;
