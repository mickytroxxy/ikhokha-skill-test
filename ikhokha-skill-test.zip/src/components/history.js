import { createBrowserHistory as history} from 'history';

export default history();