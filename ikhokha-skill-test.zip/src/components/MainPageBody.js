import React,{useState,useEffect} from "react";
import { Button, Box, Grid,Typography,Container,makeStyles, Card, CardContent, CardMedia,Snackbar  } from '@material-ui/core';
import {CameraAltOutlined,ShopOutlined } from "@material-ui/icons";
import Fab from '@material-ui/core/Fab';
import AddIcon from '@material-ui/icons/Add';
import { Alert } from '@material-ui/lab';
import ScrollMenu from 'react-horizontal-scrolling-menu';
import history from './history';
import img1 from '../img/img1.png';
import img2 from '../img/img2.png';
import img3 from '../img/logo1.png';
import img4 from '../img/img4.png';
export default function Body() {
    const classes = useStyles();
    const [state, setState] = useState({mobileView: false});
    const [open, setOpen] = React.useState(false);
    const [readMore,setReadMore]=useState(false);
    const [cards,setCards]=useState(
        [{card1:'1',cardElevation:0},{card2:'2',cardElevation:0},{card3:'3',cardElevation:0},
        {card4:'4',cardElevation:0},{card5:'5',cardElevation:0},{card6:'6',cardElevation:0}
    ]);
    const { mobileView } = state;
    const handleClick = () => {
        setOpen(true);
    };
    
    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        setOpen(false);
    };
    useEffect(() => {
        const setResponsiveness = () => {
            return window.innerWidth < 900
            ? setState((prevState) => ({ ...prevState, mobileView: true }))
            : setState((prevState) => ({ ...prevState, mobileView: false }));
        };
        setResponsiveness();
        window.addEventListener("resize", () => setResponsiveness());
    }, []);
    return (
        <Container maxWidth="xl" component="main" className={classes.heroContent}>
            <div className={classes.root}>
                <Grid container style={{marginTop:50}}>
                    <Grid item xs={12} sm={6}>
                        <div style={{padding:50}}>
                            <center><h1 style={{fontFamily:"sans-serif",color:'#3f4750'}}>Start New... Today!</h1></center>
                            <center><p style={{color:'#757575'}}>Buy your mobile point of sale for your small-medium business for a reasonable amount. Standout among your competitors! Standout among your competitors!</p></center>
                            <center><Button onClick={handleClick} style={{borderTopRightRadius:30,borderBottomLeftRadius:30}} className={classes.button} variant="outlined">REQUEST QUOTE</Button></center>
                            <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
                                <Alert onClose={handleClose} severity="success">
                                    Because of work, I would have implemented a lot
                                </Alert>
                            </Snackbar>
                        </div>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                        <center><img src={img1} style={{maxWidth:'75%'}}/></center>
                    </Grid>
                </Grid>
                <Typography style={{backgroundColor:'#f0f8fb',borderTopLeftRadius:1200,paddingBottom:15}}>
                    <div  style={{color:'#3488a7',marginTop:100,fontFamily:fontFamilyArray[5],fontSize:13}}><h2>LOREIM IPSUM SOMETHING</h2></div>
                    <Grid container style={{marginTop:50}} >
                        <Grid item xs={12} sm={6} >
                            <Box display={{ xs: 'none', md: 'block' }} m={1}>
                                <center><img src={img2} style={{maxWidth:'75%'}}/></center>
                            </Box>
                        </Grid>
                        <Grid item xs={12} sm={6}>
                            <div>
                                <center><h3 style={{color:'#737a81',fontFamily:fontFamilyArray[2],}}>New Product, new Story</h3></center>
                                <center><p style={{color:'#757575',fontFamily:fontFamilyArray[2],padding:50}}>Buy your mobile point of sale for your small-medium business for a reasonable amount. Standout among your competitors! Standout among your competitors! Standout among your competitors! Standout among your competitors!</p></center>
                                <center><Button onClick={() => history.push('/Products')} variant="outlined" className={classes.button} style={{borderRadius:20}}>EXPLORE PRODUCTS</Button></center>
                            </div>
                        </Grid>
                    </Grid>
                </Typography>
                <Typography style={{padding:10,backgroundColor:'#eef1f4',width:'100%',marginTop:50}}>
                    <div className={classes.root}>
                        <ScrollMenu
                            data={logos.map((item, i) => (
                                <div key={item} style={{width:60,height:20,marginLeft:50,marginRight:50}}>
                                    <img src={img3} alt={item} />            
                                </div>
                            ))}
                        />
                    </div>
                </Typography>
                <Typography>
                    <Container className={classes.cardGrid} maxWidth="md">
                        <Grid container spacing={3}>
                            {cards.map((item,i) => {
                                let maxLength = 4;
                                readMore?maxLength=cards.length:mobileView?maxLength=2:maxLength=4;
                                if(i < maxLength){
                                    return(
                                        <Grid item key={i} xs={12} md={3}>
                                            <Card className={classes.card} elevation={item.cardElevation} onMouseOver={()=>setCards([...cards.slice(0, i),Object.assign({}, item, {cardElevation:10}),...cards.slice(i + 1)])}onMouseOut={()=>setCards([...cards.slice(0, i),Object.assign({}, item, {cardElevation:0}),...cards.slice(i + 1)])}>
                                                <CardMedia
                                                    className={classes.cardMedia}
                                                    image={img4}
                                                    title="Image title"
                                                />
                                                <CardContent className={classes.cardContent}>
                                                    <Typography gutterBottom variant="h5" component="h2">
                                                        Blog title #1
                                                    </Typography>
                                                    <Typography>
                                                    Blog except - first lines - for approx 2 lines
                                                    </Typography>
                                                </CardContent>
                                            </Card>
                                        </Grid>
                                    )
                                } 
                            })}
                        </Grid>
                        <center><Button onClick={()=>setReadMore(!readMore)} variant="outlined" className={classes.button} style={{borderRadius:20}}>{readMore?(<span>Read Less</span>):(<span>Read More</span>)}</Button></center>
                    </Container>
                </Typography>
            </div>
            <Fab color="primary" aria-label="add" style={{position:'fixed',bottom:10,right:10}}>
                <ShopOutlined />
            </Fab>
        </Container>
    )
}
const fontFamilyArray=[
    '-apple-system',
    'BlinkMacSystemFont',
    '"Segoe UI"',
    'Roboto',
    '"Helvetica Neue"',
    'Arial',
    'sans-serif',
    '"Apple Color Emoji"',
    '"Segoe UI Emoji"',
    '"Segoe UI Symbol"',
];
const logos=[1,2,3,4,5,6,7,8];
const useStyles = makeStyles((theme) => ({
    '@global': {
      ul: {
        margin: 0,
        padding: 0,
        listStyle: 'none',
      },
    },
    heroContent: {
      padding: theme.spacing(8, 0, 6),
    },
    paper: {
        padding: theme.spacing(2),
        textAlign: 'center',
        color: theme.palette.text.secondary,
    },
    root: {
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'space-around',
        overflow: 'hidden'
    },
    gridList: {
        flexWrap: 'nowrap'
    },
    icon: {
        marginRight: theme.spacing(2),
    },
    heroButtons: {
        marginTop: theme.spacing(4),
    },
    cardGrid: {
        paddingTop: theme.spacing(8),
        paddingBottom: theme.spacing(8),
    },
    card: {
        display: 'flex',
        flexDirection: 'column',
    },
        cardMedia: {
        paddingTop: '56.25%', // 16:9
    },
        cardContent: {
        flexGrow: 1,
    },
    button: {
        marginTop:15,borderColor:'#3488a7',color:'#3488a7',outline:'none',
        '&:hover': {
          backgroundColor: '#3488a7',
          color: '#fff',
        }
    },
    footer: {
        backgroundColor: theme.palette.background.paper,
        padding: theme.spacing(6),
    },
}));