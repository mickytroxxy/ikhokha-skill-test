import {
  AppBar,
  Toolbar,
  Typography,
  makeStyles,
  Button,
  IconButton,
  Drawer,
  Link,
  MenuItem,
} from "@material-ui/core";
import MenuIcon from "@material-ui/icons/Menu";
import React, { useState, useEffect } from "react";
import { Link as RouterLink } from "react-router-dom";
import logoIcon from '../img/logo.gif';
import history from './history';
const headersData = [
  {
    label: "Home",
    href: "/",
    status:1
  },
  {
    label: "Products",
    href: "/Products",
    status:0
  },
  {
    label: "Logo",
    href: "/",
    status:0
  },
  {
    label: "Blog",
    href: "/Blog",
    status:0
  },
  {
    label: "Contact",
    href: "/Contact",
    status:0
  },
];

const useStyles = makeStyles(() => ({
  header: {
    backgroundColor: "#fff",
    paddingRight: "79px",
    paddingLeft: "118px",
    "@media (max-width: 900px)": {
      paddingLeft: 0,
    },
    
  },
  logo: {
    fontFamily: "Work Sans, sans-serif",
    fontWeight: 600,
    color: "#757575",
    textAlign: "left",
  },
  logoIconCss: {
    alignItems:'center',
  },
  menuButton: {
    fontFamily: "Open Sans, sans-serif",
    fontWeight: 700,
    size: "18px",
    marginLeft: "38px",
  },
  toolbar: {
    display: "flex",
    justifyContent: "space-between",
  },
  drawerContainer: {
    padding: "20px 30px",
  },
}));

export default function Header() {
  const { header, logo,logoIconCss, menuButton, toolbar, drawerContainer } = useStyles();
  const [state, setState] = useState({
    mobileView: false,
    drawerOpen: false,
  });

  const { mobileView, drawerOpen } = state;

  useEffect(() => {
    const setResponsiveness = () => {
      return window.innerWidth < 900
        ? setState((prevState) => ({ ...prevState, mobileView: true }))
        : setState((prevState) => ({ ...prevState, mobileView: false }));
    };
    setResponsiveness();
    window.addEventListener("resize", () => setResponsiveness());
  }, []);

  const displayDesktop = () => {
    return (
      <Toolbar className={toolbar}>
        {femmecubatorLogo}
        <div>{getMenuButtons()}</div>
      </Toolbar>
    );
  };

  const displayMobile = () => {
    const handleDrawerOpen = () =>
      setState((prevState) => ({ ...prevState, drawerOpen: true }));
    const handleDrawerClose = () =>
      setState((prevState) => ({ ...prevState, drawerOpen: false }));
    return (
      <Toolbar className={toolbar}>
        <div className={toolbar}>
          <IconButton
            {...{
              edge: "start",
              color: "#598fd5",
              "aria-label": "menu",
              "aria-haspopup": "true",
              onClick: handleDrawerOpen,
            }}
          >
            <MenuIcon />
          </IconButton>

          <Drawer {...{anchor: "left",open: drawerOpen,onClose: handleDrawerClose,}}>
            <div className={drawerContainer}>{getDrawerChoices()}</div>
          </Drawer>
          <div style={{marginTop:8}}>{femmecubatorLogo}</div>
        </div>
        <div>{displayIconLogo}</div>
      </Toolbar>
    );
  };

  const getDrawerChoices = () => {
    return headersData.map(({ label, href }) => {
      return (
        <Link
          {...{
            component: RouterLink,
            to: href,
            color: "#757575",
            style: { textDecoration: "none" },
            key: label,
          }}
        >
          <MenuItem>{label}</MenuItem>
        </Link>
      );
    });
  };

  const femmecubatorLogo = (
    <Typography variant="h6" component="h1" className={logo}>
      iKHOKHA
    </Typography>
  );
  const displayIconLogo=(
    <div className={logoIconCss}>
      <center><img src={logoIcon} height="50" /></center>
    </div>
  )
  const getMenuButtons = () => {
    return headersData.map(({ label, href,status }) => {
      return (
        <Button
          {...{
            key: label,
            color: "#757575",
            component: RouterLink,
            className: menuButton,
          }}
          onClick={() => history.push(href)}
          >
          {label=='Logo'?(<img src={logoIcon} height="50" />):label}
        </Button>
      );
    });
  };

  return (
    <header>
      <AppBar className={header} elevation={1}>
        {mobileView ? displayMobile() : displayDesktop()}
      </AppBar>
    </header>
  );
}